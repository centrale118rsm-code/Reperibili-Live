@echo off
title Reperibili Live - sfondo del desktop
setlocal
set "SELF=%~f0"
if "%SELF:~0,2%"=="\\" goto :rete
rem  Installatore in un solo file: lo script e' qui in fondo. Viene salvato come testo
rem  (niente .ps1) in una cartella permessa. Non servono permessi di amministratore.
set "RL_SRC=%~f0"
echo.
echo  Preparo lo sfondo Reperibili Live...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$t=[IO.File]::ReadAllText($env:RL_SRC,[Text.Encoding]::UTF8); $m=[char]10+':::'+'SCRIPT:::'; $i=$t.LastIndexOf($m); if($i -lt 0){exit 2}; $RLText=$t.Substring($i+$m.Length).TrimStart([char]13,[char]10); $RLMode='installa'; iex $RLText"
if errorlevel 1 (
  echo.
  echo  Installazione non riuscita: copia qui sopra le righe in rosso e mandamele.
  echo.
  pause & exit /b 1
)
echo.
echo  Fatto. Entro un minuto lo sfondo del desktop diventa il monitor dei reperibili
echo  e si aggiorna da solo ogni minuto. All'accensione del PC riparte da solo.
echo.
echo  Se non cambia nulla, guarda il file registro.txt nella cartella indicata sopra.
echo  Per toglierlo: Disinstalla-Sfondo.cmd
echo.
pause
exit /b 0
:rete
rem  Lanciato da una cartella di rete: da li' il PC non permette di avviare PowerShell.
rem  Si copia in una cartella del PC e la apre, cosi' basta un doppio clic da li'.
set "LOC=%LOCALAPPDATA%\ReperibiliLive"
if not exist "%LOC%" mkdir "%LOC%"
copy /Y "%~f0" "%LOC%\%~nx0" >nul
echo.
echo  Questo file si trova in una cartella di rete: da li' il PC non lo lascia partire.
echo  L'ho copiato in una cartella del computer, che si apre adesso:
echo  fai doppio clic su %~nx0 da quella cartella.
echo.
explorer /select,"%LOC%\%~nx0"
pause
exit /b 0
:::SCRIPT:::
# ═══════════════════════════════════════════════════════════════════════════
# REPERIBILI LIVE come SFONDO DEL DESKTOP
# Nessun programma da installare, nessun permesso di amministratore, nessun file .ps1:
# questo testo viene letto ed eseguito da PowerShell. Ogni minuto Edge, invisibile,
# "fotografa" la pagina del monitor e l'immagine diventa lo sfondo di Windows.
# Modalità ($RLMode): installa | run | ferma | disinstalla
# ═══════════════════════════════════════════════════════════════════════════
# ── Impostazioni ──
# Parametri utili nell'indirizzo:
#   area=meta   (poco meno della metà destra, tutta l'altezza)   area=quarto (quarto in alto a destra)
#   turni=0..6  orologio=1|0  reperibili=1|0  avviso=1|0  minuti=30  rubrica=1|0 (tabella codici)
$Url        = 'https://centrale118rsm-code.github.io/Reperibili-Live/?sfondo=1&area=meta'
$Intervallo = 60        # secondi fra un aggiornamento e l'altro (60 = ogni minuto, allineato all'orologio)
$Titolo     = 'I.S.S. - Servizio Informatico'   # riquadro informazioni in basso a destra (vuoto = niente riquadro)
$AttesaDati = 20000     # millisecondi lasciati alla pagina per caricare turni e reperibili

$ErrorActionPreference = 'Continue'
if(-not $RLMode){ $RLMode = 'run' }
$NomeTesto = 'ReperibiliLive-Sfondo.txt'
$avvio = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup\ReperibiliLive-Sfondo.cmd'
$candidate = @((Join-Path $env:LOCALAPPDATA 'ReperibiliLive'), (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'ReperibiliLive'), (Join-Path $env:USERPROFILE 'ReperibiliLive'))

function Cartella-Esistente { foreach($c in $candidate){ if(Test-Path (Join-Path $c $NomeTesto)){ return $c } }; return $null }
$dir = Cartella-Esistente
if(-not $dir){ $dir = $candidate[0] }
$log = Join-Path $dir 'registro.txt'
function Log($m){ try { Add-Content -Path $log -Value ("{0:yyyy-MM-dd HH:mm:ss}  {1}" -f (Get-Date), $m) } catch {} }

function Ferma-Altri {
  try {
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" |
      Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -like "*RLMode='run'*" } |
      ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  } catch {}
}
# toglie la versione "finestra" (Installa-Finestra.cmd), se c'era: i due modi non devono convivere
function Togli-Finestra {
  Remove-Item (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup\ReperibiliLive-Finestra.cmd') -Force -ErrorAction SilentlyContinue
  try {
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='msedge.exe'" |
      Where-Object { $_.ProcessId -ne $PID -and (($_.Name -eq 'powershell.exe' -and $_.CommandLine -like "*RLMode='finestra'*") -or ($_.Name -eq 'msedge.exe' -and $_.CommandLine -like '*ReperibiliLive*edge-finestra*')) } |
      ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  } catch {}
}
$wpOk = $false
try {
  Add-Type -ErrorAction Stop -TypeDefinition @"
using System; using System.Runtime.InteropServices;
public static class RLWin {
  [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)] public static extern bool SystemParametersInfo(int a, int b, string c, int d);
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] public static extern int GetSystemMetrics(int i);
}
"@
  $wpOk = $true
} catch { }
function Imposta-Sfondo($path){
  try { Set-ItemProperty 'HKCU:\Control Panel\Desktop' -Name WallPaper -Value $path } catch {}
  if($wpOk){ return [RLWin]::SystemParametersInfo(20, 0, $path, 3) }
  for($k = 0; $k -lt 3; $k++){ Start-Process rundll32.exe -ArgumentList 'user32.dll,UpdatePerUserSystemParameters 1, True' -WindowStyle Hidden -Wait }
  return $true
}
# altezza della barra delle applicazioni in basso (in pixel veri), per non coprire il riquadro PC
function Barra {
  try {
    Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
    $sc = [System.Windows.Forms.Screen]::PrimaryScreen
    $d = [int]($sc.Bounds.Bottom - $sc.WorkingArea.Bottom)
    if($d -ge 0 -and $d -lt 400){ return $d }
  } catch {}
  return -1
}
function Risoluzione {
  if($wpOk){ try { [void][RLWin]::SetProcessDPIAware(); return @([RLWin]::GetSystemMetrics(0), [RLWin]::GetSystemMetrics(1)) } catch {} }
  try { $v = Get-CimInstance Win32_VideoController | Where-Object { $_.CurrentHorizontalResolution } | Select-Object -First 1; if($v){ return @([int]$v.CurrentHorizontalResolution, [int]$v.CurrentVerticalResolution) } } catch {}
  return @(1920, 1080)
}

# ── INSTALLA: copia questo testo in una cartella permessa, avvio automatico, partenza ──
if($RLMode -eq 'installa'){
  Ferma-Altri
  Togli-Finestra
  $scelta = $null
  foreach($c in $candidate){
    try {
      New-Item -ItemType Directory -Force -Path $c -ErrorAction Stop | Out-Null
      $f = Join-Path $c $NomeTesto
      Set-Content -Path $f -Value $RLText -Encoding UTF8 -ErrorAction Stop
      $scelta = $c; break
    } catch { Write-Host ("  Cartella non permessa: " + $c) }
  }
  if(-not $scelta){ Write-Host ''; Write-Host '  Nessuna cartella permessa per salvare lo script: il PC lo blocca.'; exit 3 }
  $dir = $scelta; $log = Join-Path $dir 'registro.txt'
  $txt = Join-Path $dir $NomeTesto
  $cmdRun = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -Command `"`$RLMode='run'; iex (Get-Content -Raw -Encoding UTF8 '$txt')`""
  try { Set-Content -Path $avvio -Value ('@start "" /min powershell ' + $cmdRun) -Encoding ASCII -ErrorAction Stop }
  catch { Write-Host '  Avvio automatico non creato (cartella Esecuzione automatica bloccata): andra'' lanciato a mano.' }
  Start-Process powershell -ArgumentList $cmdRun -WindowStyle Hidden
  Log "Installato in $dir"
  Write-Host ("  Script salvato in: " + $dir)
  exit 0
}
if($RLMode -eq 'ferma'){ Ferma-Altri; exit 0 }
if($RLMode -eq 'disinstalla'){
  Ferma-Altri
  Togli-Finestra
  Remove-Item $avvio -Force -ErrorAction SilentlyContinue
  $orig = Join-Path $dir 'sfondo-originale.txt'
  if(Test-Path $orig){ $p = (Get-Content $orig -Raw).Trim(); if($p -and (Test-Path $p)){ [void](Imposta-Sfondo $p) } }
  Log 'Disinstallato'
  exit 0
}

# ── RUN: ciclo di aggiornamento dello sfondo ──
# una sola copia alla volta
try {
  $altri = Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -like "*RLMode='run'*" }
  if($altri){ exit 0 }
} catch {}
if((Test-Path $log) -and (Get-Item $log).Length -gt 1MB){ Remove-Item $log -Force -ErrorAction SilentlyContinue }
$profilo = Join-Path $dir 'edge-profilo'
New-Item -ItemType Directory -Force -Path $profilo | Out-Null
$edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
          "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
          "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe") | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if(-not $edge){ Log 'Microsoft Edge non trovato'; exit 1 }
# sfondo attuale, per rimetterlo con Disinstalla-Sfondo.cmd
$orig = Join-Path $dir 'sfondo-originale.txt'
if(-not (Test-Path $orig)){ try { (Get-ItemProperty 'HKCU:\Control Panel\Desktop').WallPaper | Set-Content -Path $orig -Encoding UTF8 } catch {} }
try {
  Set-ItemProperty 'HKCU:\Control Panel\Desktop' -Name WallpaperStyle -Value '10'   # riempi
  Set-ItemProperty 'HKCU:\Control Panel\Desktop' -Name TileWallpaper -Value '0'
} catch {}
Log ("Avvio con $edge" + $(if($wpOk){''}else{' (modalità ridotta)'}))
# informazioni del PC per il riquadro in basso a destra (passate dopo il #, non vengono inviate a internet)
function Enc($x){ return [Uri]::EscapeDataString([string]$x) }
$info = ''
if($Titolo){
  $ip = ''; $so = ''
  try { $ip = (Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True' | ForEach-Object { $_.IPAddress } | Where-Object { $_ -match '^\d+\.\d+\.\d+\.\d+$' -and $_ -notlike '169.254.*' } | Select-Object -First 1) } catch {}
  try { $cap = (Get-CimInstance Win32_OperatingSystem).Caption; if($cap -match 'Windows\s+\d+'){ $so = $Matches[0] } else { $so = $cap } } catch {}
  $info = '#titolo=' + (Enc $Titolo) + '&pc=' + (Enc $env:COMPUTERNAME) + '&utente=' + (Enc $env:USERNAME) + '&ip=' + (Enc $ip) + '&so=' + (Enc $so)
}
function OraMs { try { return [DateTimeOffset]::Now.ToUnixTimeMilliseconds() } catch { return [long](((Get-Date).ToUniversalTime() - [datetime]'1970-01-01').TotalMilliseconds) } }
$ofs = 7000      # quanto ci mette di solito la foto a diventare sfondo (si aggiorna da solo)
$n = 0
while($true){
  try {
    $r = Risoluzione; $w = $r[0]; $h = $r[1]
    $file = Join-Path $dir ("sfondo-{0}.png" -f ($n % 2))     # due nomi alternati: Windows ricarica sempre l'immagine
    $tmp  = Join-Path $dir 'scatto.png'
    Remove-Item $tmp -Force -ErrorAction SilentlyContinue
    $sep = '?'; if($Url -match '\?'){ $sep = '&' }
    $t0 = OraMs
    $tb = Barra
    $hash = $info; if(-not $hash){ $hash = '#x=1' }
    if($tb -ge 0){ $hash += '&tb=' + $tb }
    $u = $Url + $sep + 'ts=' + $t0 + '&ofs=' + $ofs + $hash
    $argv = "--headless --disable-gpu --hide-scrollbars --mute-audio --no-first-run --no-default-browser-check " +
            "--user-data-dir=`"$profilo`" --window-size=$w,$h --force-device-scale-factor=1 " +
            "--virtual-time-budget=$AttesaDati --screenshot=`"$tmp`" `"$u`""
    $p = Start-Process -FilePath $edge -ArgumentList $argv -WindowStyle Hidden -PassThru
    Wait-Process -Id $p.Id -Timeout 90 -ErrorAction SilentlyContinue
    if(Get-Process -Id $p.Id -ErrorAction SilentlyContinue){ Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue; Log 'Edge non ha risposto in tempo' }
    if((Test-Path $tmp) -and (Get-Item $tmp).Length -gt 15000){
      Move-Item $tmp $file -Force
      if(Imposta-Sfondo $file){
        $n++
        $durata = (OraMs) - $t0
        if($durata -gt 1500 -and $durata -lt 45000){ $ofs = [int](($ofs * 2 + $durata) / 3) }
      } else { Log 'Windows ha rifiutato lo sfondo (forse bloccato dai criteri aziendali)' }
    } else { Log 'Nessuna immagine prodotta (Edge invisibile bloccato o pagina non raggiungibile)' }
  } catch { Log ('Errore: ' + $_.Exception.Message) }
  # riparte in modo che la nuova immagine compaia allo scoccare di :00, :15, :30, :45 (o del minuto)
  if($Intervallo -lt 10){ $Intervallo = 10 }
  $ora = OraMs
  $passo = [long]$Intervallo * 1000
  $prossimo = [long]([Math]::Floor(($ora + $ofs) / $passo) + 1) * $passo - $ofs
  $attesa = $prossimo - $ora
  if($attesa -lt 1000){ $attesa += $passo }
  Start-Sleep -Milliseconds ([int]$attesa)
}
